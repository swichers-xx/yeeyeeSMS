<?php
// cred.php
// created by: Kristen
// created on: Feb 8 2020

//PURPOSE: database access credentials

//LOCAL VARIABLES BELOW -- COMMENT BEFORE COMMITTING
// $servername = "localhost";
// $username = "root";
// $password = "RastE4em";
// $dbname = "lucer_twilio";

// LUCE RESEARCH VARIABLES BELOW -- UNCOMMENT BEFORE COMMITTING
$servername = "127.0.0.1";
$username = "lucer_Twilio";
$password = "XBoS2xw-PCTK";
$dbname = "lucer_Twilio";

?>